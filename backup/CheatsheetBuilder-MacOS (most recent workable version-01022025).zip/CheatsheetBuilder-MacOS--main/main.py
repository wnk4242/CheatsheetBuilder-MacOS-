from menu import main_menu

if __name__ == "__main__":
    # Start the main menu
    main_menu()
